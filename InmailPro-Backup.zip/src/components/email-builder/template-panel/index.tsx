import React from 'react'

import { MonitorOutlined, PhoneIphoneOutlined } from '@mui/icons-material'
import { Box, Stack, SxProps, ToggleButton, ToggleButtonGroup, Tooltip } from '@mui/material'
import { Reader } from '@usewaypoint/email-builder'

import EditorBlock from '../editor/EditorBlock'
import {
  setSelectedScreenSize,
  useDocument,
  useSelectedMainTab,
  useSelectedScreenSize,
  useZoom,
} from '../editor/EditorContext'
import ToggleInspectorPanelButton from '../inspector/ToggleInspectorPanelButton'
import ToggleSamplesPanelButton from '../samples/ToggleSamplesPanelButton'

import HtmlPanel from './HtmlPanel'
import JsonPanel from './JsonPanel'
import MainTabsGroup from './MainTabsGroup'

export default function TemplatePanel() {
  const document = useDocument()
  const selectedMainTab = useSelectedMainTab()
  const selectedScreenSize = useSelectedScreenSize()
  const zoom = useZoom()

  const zoomPercent = zoom / 100

  let mainBoxSx: SxProps = {
    height: '100%',
    transform: `scale(${zoomPercent})`,
    transformOrigin: 'top center',
  }
  if (selectedScreenSize === 'mobile') {
    mainBoxSx = {
      ...mainBoxSx,
      margin: '32px auto',
      width: 370,
      height: 800,
      boxShadow:
        'rgba(33, 36, 67, 0.04) 0px 10px 20px, rgba(33, 36, 67, 0.04) 0px 2px 6px, rgba(33, 36, 67, 0.04) 0px 0px 1px',
    }
  }

  const handleScreenSizeChange = (_: unknown, value: unknown) => {
    switch (value) {
      case 'mobile':
      case 'desktop':
        setSelectedScreenSize(value)
        return
      default:
        setSelectedScreenSize('desktop')
    }
  }

  const renderMainPanel = () => {
    switch (selectedMainTab) {
      case 'editor':
        return (
          <Box sx={mainBoxSx}>
            <EditorBlock id="root" />
          </Box>
        )
      case 'preview':
        return (
          <Box sx={mainBoxSx}>
            <Reader document={document} rootBlockId="root" />
          </Box>
        )
      case 'html':
        return <HtmlPanel />
      case 'json':
        return <JsonPanel />
    }
  }

  return (
    <>
      <Stack
        sx={{
          height: 49,
          borderBottom: 1,
          borderColor: 'divider',
          backgroundColor: 'white',
          position: 'sticky',
          top: 0,
          zIndex: 'appBar',
          px: 1,
          justifyContent: 'space-between',
          alignItems: 'center',
        }}
        direction="row"
      >
        <ToggleSamplesPanelButton />
        <Stack
          sx={{ px: 2, gap: 2, width: '100%', justifyContent: 'space-between', alignItems: 'center' }}
          direction="row"
        >
          <Stack direction="row" spacing={2}>
            <MainTabsGroup />
          </Stack>
          <Stack direction="row" spacing={2}>
            <ToggleButtonGroup value={selectedScreenSize} exclusive size="small" onChange={handleScreenSizeChange}>
              <ToggleButton value="desktop">
                <Tooltip title="Desktop view">
                  <MonitorOutlined fontSize="small" />
                </Tooltip>
              </ToggleButton>
              <ToggleButton value="mobile">
                <Tooltip title="Mobile view">
                  <PhoneIphoneOutlined fontSize="small" />
                </Tooltip>
              </ToggleButton>
            </ToggleButtonGroup>
          </Stack>
        </Stack>
        <ToggleInspectorPanelButton />
      </Stack>
      <Box
        sx={{
          height: 'calc(100vh - 49px)',
          overflow: 'auto',
          minWidth: 370,
          display: 'flex',
          justifyContent: 'center',
          bgcolor: '#e8e8e8',
        }}
      >
        {renderMainPanel()}
      </Box>
    </>
  )
}
